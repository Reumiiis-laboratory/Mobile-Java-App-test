package com.example.myapplication;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainMenu extends AppCompatActivity {

    private FrameLayout addOverlay;   // FrameLayout to show/hide
    private View btnAdd;         // Button to show the overlay

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // Find Views
        addOverlay = findViewById(R.id.add_overlay);
        btnAdd =  findViewById(R.id.btn_add);

        // Show FrameLayout when btn_add is clicked
        btnAdd.setOnClickListener(v -> addOverlay.setVisibility(View.VISIBLE));

        // Hide FrameLayout when clicked outside of it
        addOverlay.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Detect click outside the FrameLayout
                if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                    addOverlay.setVisibility(View.GONE);
                    return true;
                }
                return false;
            }
        });

        // Add a listener for clicks outside the FrameLayout
        findViewById(R.id.main).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Hide the overlay if clicked outside of the frame layout
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (!isViewInBounds(addOverlay, event)) {
                        addOverlay.setVisibility(View.GONE);
                    }
                }
                return true;
            }
        });

        // Sample data for the list
        ArrayList<String> items = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            items.add("Item " + i);
        }

        // Set up the ListView with a custom adapter
        ListView listView = findViewById(R.id.list_view);
        CustomAdapter adapter = new CustomAdapter(items);
        listView.setAdapter(adapter);
    }

    // Custom Adapter class
    private class CustomAdapter extends android.widget.BaseAdapter {
        private final ArrayList<String> items;

        public CustomAdapter(ArrayList<String> items) {
            this.items = items;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.list_layout, parent, false);
            }

            // Bind data to views
            TextView itemText = convertView.findViewById(R.id.item_text);
            ImageView btnEdit = convertView.findViewById(R.id.btn_edit);

            itemText.setText(items.get(position));

            // ActionListener for btnEdit
            btnEdit.setOnClickListener(v -> {
                // Handle ImageView click
                String message = "Pencil icon clicked on " + items.get(position);
                System.out.println(message);
                Toast.makeText(MainMenu.this, message, Toast.LENGTH_SHORT).show();
            });

            return convertView;
        }
    }

    // Helper function to check if the touch event is inside the view bounds
    private boolean isViewInBounds(View view, MotionEvent event) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        int x = (int) event.getRawX();
        int y = (int) event.getRawY();
        return x >= location[0] && x <= location[0] + view.getWidth() &&
                y >= location[1] && y <= location[1] + view.getHeight();
    }
}
