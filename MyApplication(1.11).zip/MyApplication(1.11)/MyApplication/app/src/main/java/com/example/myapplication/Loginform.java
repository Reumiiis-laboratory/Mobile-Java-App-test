package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Loginform extends AppCompatActivity {

    private Button btn_login;
    private EditText txt_username;
    private EditText txt_password;
    private TextView txt_sign_up;  // Declare the TextView for sign up link

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginform);

        // Initialize the views
        btn_login = findViewById(R.id.btn_login);
        txt_username = findViewById(R.id.txt_username);
        txt_password = findViewById(R.id.txt_password);
        txt_sign_up = findViewById(R.id.txt_signUp);  // Initialize the TextView

        // Set OnClickListener for the Login button
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLoginClick();
            }
        });

        // Set OnClickListener for the Sign Up TextView
        txt_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open the SignUpActivity when clicked
                openSignUpPage();
            }
        });
    }

    // Method to handle the Login button click action
    private void handleLoginClick() {
        String username = txt_username.getText().toString();
        String password = txt_password.getText().toString();

        if (validateLogin(username, password)) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainMenu.class);  // Replace 'MainMenuActivity.class' with your actual Main Menu Activity class
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
            txt_username.setText("");
            txt_password.setText("");
        }
    }

    // Method to validate the login
    private boolean validateLogin(String username, String password) {
        return username.equals("Reumiii") && password.equals("123");  // Example validation
    }

    // Method to navigate to the SignUpActivity (sign-up page)
    private void openSignUpPage() {
        // Create an Intent to start the SignUpActivity
        Intent intent = new Intent(Loginform.this, Signupform.class);  // Replace SignUpActivity with your actual sign-up activity class
        startActivity(intent);
    }
}
