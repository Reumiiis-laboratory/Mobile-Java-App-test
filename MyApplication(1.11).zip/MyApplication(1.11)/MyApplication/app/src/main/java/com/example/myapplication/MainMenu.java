package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainMenu extends AppCompatActivity {

    private FrameLayout addOverlay, personOverlay;   // FrameLayouts for options
    private View btnAdd, btnPersonSettings;          // Buttons to show the overlays
    private ListView listView;                       // ListView to show items

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // Find Views
        addOverlay = findViewById(R.id.add_overlay);
        personOverlay = findViewById(R.id.person_overlay);
        btnAdd = findViewById(R.id.btn_add);
        btnPersonSettings = findViewById(R.id.btn_personsettings);
        listView = findViewById(R.id.list_view);   // Initialize ListView

        // Show the add overlay when btn_add is clicked
        btnAdd.setOnClickListener(v -> {
            addOverlay.setVisibility(View.VISIBLE);   // Show the add overlay
        });

        // Show the person overlay when btn_personsettings is clicked
        btnPersonSettings.setOnClickListener(v -> {
            personOverlay.setVisibility(View.VISIBLE);   // Show the person overlay (settings, logout, etc.)
        });

        // Add a listener for clicks outside the FrameLayouts to hide them
        findViewById(R.id.main).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Hide the overlays if clicked outside of them
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (!isViewInBounds(addOverlay, event) && !isViewInBounds(personOverlay, event)) {
                        addOverlay.setVisibility(View.GONE);
                        personOverlay.setVisibility(View.GONE);
                    }
                }
                return true;
            }
        });

        // Handle clicking on options in addOverlay
        findViewById(R.id.option_add_income).setOnClickListener(v -> showToast("Add Income clicked"));
        findViewById(R.id.option_add_expense).setOnClickListener(v -> showToast("Add Expense clicked"));
        findViewById(R.id.option_add_target).setOnClickListener(v -> showToast("Add Target clicked"));

        // Handle clicking on options in personOverlay
        findViewById(R.id.option_settings).setOnClickListener(v -> showToast("Settings clicked"));
        findViewById(R.id.option_about_us).setOnClickListener(v -> showToast("About Us clicked"));
        findViewById(R.id.option_log_out).setOnClickListener(v -> handleLogout());

        // Set up ListView with custom adapter
        ArrayList<String> data = new ArrayList<>();
        data.add("Income | Daily: 300");
        data.add("Expense| today: 150");
        data.add("Income | Weekly: 500");
        data.add("Income | Daily: 100 ");


        CustomAdapter adapter = new CustomAdapter(data);
        listView.setAdapter(adapter); // Set the adapter for the ListView
    }

    // Helper function to check if the touch event is inside the view bounds
    private boolean isViewInBounds(View view, MotionEvent event) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        int x = (int) event.getRawX();
        int y = (int) event.getRawY();
        return x >= location[0] && x <= location[0] + view.getWidth() &&
                y >= location[1] && y <= location[1] + view.getHeight();
    }

    // Show a toast message (for demo purposes)
    private void showToast(String message) {
        Toast.makeText(MainMenu.this, message, Toast.LENGTH_SHORT).show();
    }

    // Handle Logout (redirect to Login form)
    private void handleLogout() {
        // Show a toast or perform other actions on logout if needed
        Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();

        // Redirect to the Login form
        Intent intent = new Intent(MainMenu.this, Loginform.class);  // Change to your Login Activity class
        startActivity(intent);

        // Optionally finish the current activity
        finish();
    }

    // Custom Adapter for ListView
    private class CustomAdapter extends android.widget.BaseAdapter {
        private final ArrayList<String> items;

        public CustomAdapter(ArrayList<String> items) {
            this.items = items;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.list_layout, parent, false);
            }

            // Bind data to views
            TextView itemText = convertView.findViewById(R.id.item_text);
            ImageView btnEdit = convertView.findViewById(R.id.btn_edit);

            itemText.setText(items.get(position));

            // ActionListener for btnEdit
            btnEdit.setOnClickListener(v -> {
                // Handle ImageView click
                String message = "Pencil icon clicked on " + items.get(position);
                System.out.println(message);
                Toast.makeText(MainMenu.this, message, Toast.LENGTH_SHORT).show();
            });

            return convertView;
        }
    }
}
