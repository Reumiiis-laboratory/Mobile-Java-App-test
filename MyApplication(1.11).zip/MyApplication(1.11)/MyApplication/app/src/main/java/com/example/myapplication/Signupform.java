package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Signupform extends AppCompatActivity {

    private TextView txtEmail, txtUsername, txtPassword, txtConfirmPassword, txtLogin;
    private Button btnSignin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signupform);

        // Initialize views
        txtEmail = findViewById(R.id.txt_email);
        txtUsername = findViewById(R.id.txt_username);
        txtPassword = findViewById(R.id.txt_password);
        txtConfirmPassword = findViewById(R.id.txt_confirmpassword);
        btnSignin = findViewById(R.id.btn_signup);
        txtLogin = findViewById(R.id.txt_login); // Corrected variable name here

        // Set Edge to Edge layout (if you want to handle system insets)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set the button click listener
        btnSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSignupClick();
            }
        });

        // Set the click listener for the "Login" TextView
        txtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLoginRedirect();
            }
        });
    }

    private void handleSignupClick() {
        // Get input values from the user
        String email = txtEmail.getText().toString();
        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();
        String confirmPassword = txtConfirmPassword.getText().toString();

        // Validate the input
        if (validateSignup(email, username, password, confirmPassword)) {
            // If validation is successful, go to the login form
            Intent intent = new Intent(Signupform.this, Loginform.class);  // Change LoginActivity.class to your login activity
            startActivity(intent);

            // Optionally, finish this activity to prevent going back to the signup form
            finish();
        }
    }

    private void handleLoginRedirect() {
        // Redirect to the Loginform activity
        Intent intent = new Intent(Signupform.this, Loginform.class); // Replace with your actual Login form activity
        startActivity(intent);
    }

    private boolean validateSignup(String email, String username, String password, String confirmPassword) {
        // Validate email using regex
        String emailPattern = "[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}";
        if (!email.matches(emailPattern)) {
            Toast.makeText(this, "Invalid email format", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Validate password and confirm password
        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return false;
        }

        // You can add more validation for the password (length, special characters, etc.)
        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters long", Toast.LENGTH_SHORT).show();
            return false;
        }

        // If all validations pass, return true
        return true;
    }
}
