package com.example.myapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

import java.util.List;

public class CustomAdapter extends BaseAdapter {
    private Context context;
    private List<String> items;

    public CustomAdapter(Context context, List<String> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_layout, parent, false);
        }

        TextView itemText = convertView.findViewById(R.id.item_text);
        ImageView btnEdit = convertView.findViewById(R.id.btn_edit);

        // Set the text for the list item
        itemText.setText(items.get(position));

        // Set the click listener for the edit button
        btnEdit.setOnClickListener(v -> {
            // Create an EditText field for input
            EditText input = new EditText(context);
            input.setInputType(InputType.TYPE_CLASS_TEXT);
            input.setText(items.get(position)); // Pre-fill with current item text

            // Show the edit dialog
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Edit Item")
                    .setView(input)
                    .setPositiveButton("Save", (dialog, which) -> {
                        String newItem = input.getText().toString();
                        items.set(position, newItem);  // Update the list item
                        notifyDataSetChanged();  // Notify the adapter to refresh the list
                        Toast.makeText(context, "Item Updated: " + newItem, Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.cancel())
                    .create()
                    .show();
        });

        return convertView;
    }
}
