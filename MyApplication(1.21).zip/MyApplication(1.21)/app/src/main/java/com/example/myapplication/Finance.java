package com.example.myapplication;

public class Finance {
    private String type;
    private String name;
    private float price;

    private String id;


    public Finance() {}

    public Finance(String type,String name, float price) {
        this.type =type;
        this.name = name;
        this.price = price;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    // Getter and Setter for 'name'
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    // Getter and Setter for 'genre'
    public float getprice() {
        return price;
    }
    public void setprice(String price) {
        this.price = Float.parseFloat(price);
    }

    public String getType() {
        return type;
    }
    public void settype(String type) {
        this.type = type;
    }

}
