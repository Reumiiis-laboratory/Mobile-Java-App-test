package com.example.myapplication;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        btnAdd = findViewById(R.id.btn_add);
        btnAdd.setOnClickListener(view -> showAddDialog());
    }

    private void showAddDialog() {
        // Create a dialog box that allows the user to select an option (e.g., Add Transaction, Expense, Income)
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose an option")
                .setItems(new String[]{"Add Transaction", "Income", "Expense"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                // Handle Add Transaction
                                Toast.makeText(MainActivity.this, "Add Transaction selected", Toast.LENGTH_SHORT).show();
                                break;
                            case 1:
                                // Handle Income
                                Toast.makeText(MainActivity.this, "Income selected", Toast.LENGTH_SHORT).show();
                                break;
                            case 2:
                                // Handle Expense
                                Toast.makeText(MainActivity.this, "Expense selected", Toast.LENGTH_SHORT).show();
                                break;
                        }
                    }
                })
                .setCancelable(true)
                .create()
                .show();
    }
}
