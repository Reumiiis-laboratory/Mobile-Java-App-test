package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainMenu extends AppCompatActivity {


    private View btnAdd;              // Button to show the overlay
    private ListView listView;        // ListView to show items
    private ArrayList<String> listItems; // List of items in the ListView
    private ArrayAdapter<String> adapter;

    private TextView txt_db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);



        // Initialize Views

        btnAdd = findViewById(R.id.btn_add);
        listView = findViewById(R.id.list_view);
        txt_db = findViewById(R.id.txt_db);
        float total_expense,total_saved,total_profits;
        total_expense = 3;
        total_saved = 4;
        total_profits = 5;
        String texts = "Total Expense" + total_expense+"\nTotal Saved:" +total_saved + "\nTotal Profits: " +total_profits;

        txt_db.setText(texts);


       // Initialize List and Adapter
        listItems = new ArrayList<>();
        listItems.add("Item 1");
        listItems.add("Item 2");
        listItems.add("Item 3");
        adapter = new ArrayAdapter<>(this, R.layout.list_layout, R.id.item_text, listItems);
        listView.setAdapter(adapter);

        // Show the add overlay when btn_add is clicked
        btnAdd.setOnClickListener(v -> {
               // Show the add overlay
            showAddItemDialog(); // Show dialog to add item
        });

        // Handle list item clicks to edit or delete items
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = listItems.get(position);
            ImageView editButton = view.findViewById(R.id.btn_edit);
            ImageView deleteButton = view.findViewById(R.id.btn_delete);

            // Edit the selected item when the pencil icon is clicked
            editButton.setOnClickListener(v -> {
                showEditItemDialog(position, selectedItem); // Show dialog to edit item
            });

            // Delete the selected item when the delete icon is clicked
            deleteButton.setOnClickListener(v -> {
                listItems.remove(position); // Remove the item
                adapter.notifyDataSetChanged(); // Refresh the ListView
                Toast.makeText(MainMenu.this, "Item Deleted", Toast.LENGTH_SHORT).show();
            });
        });

        // Handle Person Settings button click
        ImageView personSettingsButton = findViewById(R.id.btn_personsettings);
        personSettingsButton.setOnClickListener(v -> {
            // Show settings dialog
            showSettingsDialog();
        });

        // Hide overlay if clicked outside the overlay

    }

    // Helper function to check if a touch event is inside a specific view
    private boolean isViewInBounds(View view, MotionEvent event) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        int x = (int) event.getRawX();
        int y = (int) event.getRawY();
        return x >= location[0] && x <= location[0] + view.getWidth() &&
                y >= location[1] && y <= location[1] + view.getHeight();
    }

    // Method to show dialog for adding a new item
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose Action");

        // Define the options
        String[] options = {"Add Expense", "Add Income", "Refresh"};

        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0: // Add Expense
                    promptForNameAndPrice("Expense");
                    break;

                case 1: // Add Income
                    promptForNameAndPrice("Income");
                    break;

                case 2: // Refresh
                    refreshList();
                    break;
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // Prompt for Name and Price for Expense or Income
    private void promptForNameAndPrice(String type) {
        // First prompt for the name
        AlertDialog.Builder nameDialog = new AlertDialog.Builder(this);
        nameDialog.setTitle("Enter " + type + " Name");

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Enter name");
        nameDialog.setView(nameInput);

        nameDialog.setPositiveButton("Next", (dialog, which) -> {
            String name = nameInput.getText().toString();
            if (!name.isEmpty()) {
                promptForPrice(type, name); // Proceed to ask for price
            } else {
                Toast.makeText(MainMenu.this, type + " name cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        nameDialog.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        nameDialog.show();
    }

    // Prompt for Price and Save to Firebase
    private void promptForPrice(String type, String name) {
        AlertDialog.Builder priceDialog = new AlertDialog.Builder(this);
        priceDialog.setTitle("Enter " + type + " Price");

        final EditText priceInput = new EditText(this);
        priceInput.setHint("Enter price");
        priceInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        priceDialog.setView(priceInput);

        priceDialog.setPositiveButton("Add", (dialog, which) -> {
            String price = priceInput.getText().toString();
            if (!price.isEmpty()) {
                // Validate that the price is a positive number using regex
                if (price.matches("^\\d+(\\.\\d+)?$")) { // Matches numbers like "123" or "123.45"
                    float nprice = Float.parseFloat(price); // Convert to float
                    if (nprice >= 0) { // Ensure it's not negative
                        saveToFirebase(type, name, nprice); // Save the data to Firebase
                    } else {
                        Toast.makeText(MainMenu.this, "Price cannot be negative", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainMenu.this, "Invalid price format. Please enter a valid number.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainMenu.this, type + " price cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        priceDialog.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        priceDialog.show();
    }

    // Save data to Firebase
    private void saveToFirebase(String type, String name, float price) {
        // Get a reference to the Firebase Realtime Database
        DatabaseReference database = FirebaseDatabase.getInstance().getReference();

        // Generate a unique key for each entry
        String key = database.child(type).push().getKey();

        if (key != null) {
            // Create an object of Finance (custom model class) to represent the data
            Finance data = new Finance(type, name, price);

            // Save the data under the respective type (e.g., Expense or Income) with the unique key
            database.child(type).child(key).setValue(data).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    // Notify the user and update the ListView
                    Toast.makeText(MainMenu.this, type + " Added Successfully", Toast.LENGTH_SHORT).show();
                    listItems.add(type + ": " + name + " - $" + String.format("%.2f", price)); // Format price to two decimal places
                    adapter.notifyDataSetChanged(); // Refresh the ListView
                } else {
                    // Notify the user of the failure
                    Toast.makeText(MainMenu.this, "Failed to add " + type + ". Please try again.", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                // Handle potential exceptions and notify the user
                Toast.makeText(MainMenu.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        } else {
            // Notify the user if the key could not be generated
            Toast.makeText(MainMenu.this, "Failed to generate unique key. Try again.", Toast.LENGTH_SHORT).show();
        }
    }


    // Action for "Refresh"
    private void refreshList() {
        // Clear the list and refresh
        listItems.clear();
        adapter.notifyDataSetChanged();
        Toast.makeText(MainMenu.this, "List Refreshed", Toast.LENGTH_SHORT).show();
    }

    // Method to show dialog for editing an existing item
    private void showEditItemDialog(int position, String selectedItem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Item");

        // Create an input field pre-filled with the current item value
        final EditText input = new EditText(this);
        input.setText(selectedItem);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String updatedItem = input.getText().toString();
            if (!updatedItem.isEmpty()) {
                listItems.set(position, updatedItem); // Update the selected item
                adapter.notifyDataSetChanged(); // Refresh the ListView
                Toast.makeText(MainMenu.this, "Item Updated: " + updatedItem, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainMenu.this, "Item cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Method to show the settings dialog with options to view profile or log out
    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Settings");

        builder.setItems(new CharSequence[]{"View Profile", "Logout"}, (dialog, which) -> {
            switch (which) {
                case 0: // View Profile clicked
                    Toast.makeText(MainMenu.this, "View Profile clicked", Toast.LENGTH_SHORT).show();
                    // Navigate to Profile activity (You need to create the Profile activity)
                    break;
                case 1: // Logout clicked
                    logout();
                    break;
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Method to handle logout and navigate back to login screen
    private void logout() {
        Intent intent = new Intent(MainMenu.this, Loginform.class);
        startActivity(intent);
        finish(); // Close the MainMenu activity so user can't go back to it
        Toast.makeText(MainMenu.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}
