package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;



public class MainMenu extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // Sample data for the list
        ArrayList<String> items = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            items.add("Item " + i);
        }

        // Set up the ListView with a custom adapter
        ListView listView = findViewById(R.id.list_view);
        CustomAdapter adapter = new CustomAdapter(items);
        listView.setAdapter(adapter);
    }

    // Custom Adapter class
    private class CustomAdapter extends android.widget.BaseAdapter {
        private final ArrayList<String> items;

        public CustomAdapter(ArrayList<String> items) {
            this.items = items;
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.list_layout, parent, false);
            }

            // Bind data to views
            TextView itemText = convertView.findViewById(R.id.item_text);
            ImageView btn_edit = convertView.findViewById(R.id.btn_edit);

            itemText.setText(items.get(position));

            /*
            ActionListener for btn_edit
             */
            btn_edit.setOnClickListener(v -> {
                // Handle ImageView click
                String message = "Pencil icon clicked on " + items.get(position);
                System.out.println(message);
            });

            return convertView;
        }
    }
}